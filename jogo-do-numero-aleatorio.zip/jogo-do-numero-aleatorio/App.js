import { useState } from 'react'
import { View, Text, Button, TextInput, Image } from 'react-native'
import {styles} from './styles'

import img from'assets/rand.jpg';



export default function App(){
  const [rand, setRand] = useState()

 
  return(
    <View>
      <Text style={styles.titulo}>Jogo do numero aleatorio</Text>

      <Image source={img}/>

      <Text style={styles.titulo}>Pense em um número de 1 a 10</Text>
      <Text
      style={styles.input}
      >{rand}</Text>


      <Button title='Calcular' color='green' onPress={() => setRand(Math.floor(Math.random() * 11), )}/>


    </View>
  )
}

