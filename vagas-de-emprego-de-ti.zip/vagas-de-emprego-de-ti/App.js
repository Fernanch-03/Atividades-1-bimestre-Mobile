import React, { Component } from 'react';
import { View, StyleSheet, ScrollView, Text, Image } from 'react-native';
import {styles} from './styles';



function App(){
  return(
    
    <View style={styles.container}>
    <Text style={styles.titulo}>
      Anuncios
    </Text>
      <ScrollView vertical={true} showsVerticalScrollIndicator={true}>
        <View style={styles.a1}>
        <Text style={styles.titulocargo}>Desenvolvedor Java Full Stack</Text>
        <Text>Salario: R$4.597,00</Text>
        <Text>Descrição: Possuir conhecimento avançado em java, estar disponível a trabalhar 8horas por dia de segunda a sexta</Text>
        <Text>Contato:(13)99999-9999</Text>
        </View>
        
        <View style={styles.a1}>
        <Text style={styles.titulocargo}>Desenvolvedor Java Full Stack</Text>
        <Text>Salario: R$4.597,00</Text>
        <Text>Descrição: Possuir conhecimento avançado em java, estar disponível a trabalhar 8horas por dia de segunda a sexta</Text>
        <Text>Contato:(13)99999-9999</Text>
        </View>

        <View style={styles.a1}>
        <Text style={styles.titulocargo}>Desenvolvedor Java Full Stack</Text>
        <Text>Salario: R$4.597,00</Text>
        <Text>Descrição: Possuir conhecimento avançado em java, estar disponível a trabalhar 8horas por dia de segunda a sexta</Text>
        <Text>Contato:(13)99999-9999</Text>
        </View>

        <View style={styles.a1}>
        <Text style={styles.titulocargo}>Desenvolvedor Java Full Stack</Text>
        <Text>Salario: R$4.597,00</Text>
        <Text>Descrição: Possuir conhecimento avançado em java, estar disponível a trabalhar 8horas por dia de segunda a sexta</Text>
        <Text>Contato:(13)99999-9999</Text>
        </View>
        
        <View style={styles.a1}>
        <Text style={styles.titulocargo}>Desenvolvedor Java Full Stack</Text>
        <Text>Salario: R$4.597,00</Text>
        <Text>Descrição: Possuir conhecimento avançado em java, estar disponível a trabalhar 8horas por dia de segunda a sexta</Text>
        <Text>Contato:(13)99999-9999</Text>
        </View>

      </ScrollView>
    </View>
  )
}



export default App;
