import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
  container:{
    flex: 1
  },
  a1:{
    backgroundColor: 'white',
    height: 150,
    width: '80%',
    textAlign: 'left',
    border: 'solid',
    marginBottom: 20,
  },
  a2:{
    backgroundColor: 'white',
    height: 400,
    width: 230,
    textAlign: 'center',
  },
  a3:{
    backgroundColor: 'yellow',
    height: 400,
    width: 276,
    textAlign: 'center',
  },
  titulo:{
    fontSize: 25,
    textAlign: 'center',
    color: 'red',
    
  },
  titulocargo:{
    color:'blue',
  },

})

export {styles}