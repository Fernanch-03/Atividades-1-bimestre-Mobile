import { useState } from 'react'
import { View, Text, Button, TextInput, Image, Switch } from 'react-native'
import {styles} from './styles'

import {Picker} from '@react-native-picker/picker';
import Slider from '@react-native-community/slider';


export default function App(){
  const [status, setStatus] = useState(false)
  const [nome, setNome] = useState()
  const [idade, setIdade] = useState()
  const [sexo, setSexo] = useState()
  const [escolaridade, setEscolaridade] = useState()
  const [limite,setLimite] = useState(0)
  const [resNome,setResNome] = useState()
  const [resIdade,setResIdade] = useState()
  const [resSexo,setResSexo] = useState()
  const [resEscolaridade,setResEscolaridade] = useState()
  const [resLimite,setResLimite] = useState()
  const [resBrasileiro,setResBraileiro] = useState()

  

  return(
    <View>
      <Text style={styles.titulo}>Calculo IMC</Text>

      <TextInput
      style={styles.input}
      placeholder="Nome"
      onChangeText={setNome}
      />


      <TextInput
      style={styles.input}
      placeholder="Idade"
      onChangeText={setIdade}
      />

      Sexo:
      <Picker styles={styles.input}
      selectedValue={sexo}
      onValueChange={ (itemValue, itemIndex) => setSexo(itemValue) }
      >
        <Picker.Item key={1} value={'Masculino'} label="Masculino" />
        <Picker.Item key={2} value={'Feminino'} label="Feminino" />
        <Picker.Item key={3} value={'Outro'} label="Outro" />
      </Picker>

      Escolaridade:
      <Picker styles={styles.input}
      selectedValue={escolaridade}
      onValueChange={ (itemValue, itemIndex) => setEscolaridade(itemValue) }
      >
        <Picker.Item key={1} value={'Infantil'} label="Infantil" />
        <Picker.Item key={2} value={'Fundamental'} label="Fundamental" />
        <Picker.Item key={3} value={'Médio'} label="Médio" />
      </Picker>
      
      Limite:
      <Slider
        minimumValue={0}
        maximumValue={201}
        step={1}
        onValueChange={ (valorSelecionado) => setLimite(valorSelecionado) }
        value={limite}
      />
      <Text style={{textAlign: 'center', fontSize: 30}}>
        {limite.toFixed(0)}
      </Text>

      Brasileiro:<Switch
      value={status}
      onValueChange={ (valorSwitch) => setStatus(valorSwitch) }
      />


      <Button title='Calcular' color='green' onPress={concluir()} />
        <Text style={{color: 'blue', fontSize:25}}>Dados Informados</Text>
        <Text>Nome: {resNome}</Text>
        <Text>Idade: {resIdade}</Text>
        <Text>Sexo: {resSexo}</Text>
        <Text>Escolaridade: {resEscolaridade}</Text>
        <Text>Limite: {resLimite}</Text>
        <Text>Brasileiro?: {(resBrasileiro) ? "Sim" : "Não"}</Text>
    </View>
  )
  function concluir(){
      {setResNome=>(nome);
      setResIdade=>(idade);
      setResSexo=>(sexo);
      setResEscolaridade=>(escolaridade);
      setResLimite=>(limite);
      setResBraileiro=>(status);
      }

  }
}

