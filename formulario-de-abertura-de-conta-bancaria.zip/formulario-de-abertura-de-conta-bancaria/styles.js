import {StyleSheet} from 'react-native'




const styles = StyleSheet.create({
  titulo:{
    fontSize: 35,
    marginTop: 15,
    textAlign: 'center'
  },
  resultado: {
    fontSize: 15,
    textAlign: 'center',
    color: 'red'
  },
  input:{
    height: 45,
    borderWidth: 1,
    borderColor: '#222',
    margin: 10,
    fontSize: 20,
    padding: 10,
  },
})




export {styles}