import { useState } from 'react'
import { View, Text, Button, TextInput, Image} from 'react-native'
import {styles} from './styles'

import img from 'assets/alcoolGasolina.png';

export default function App(){
  
  const [alcool, setalcool] = useState()
  const [gasolina, setgasolina] = useState()
  const [resultado, setResultado] = useState('')

  function qualMelhor(){
    melhor = alcool/gasolina
    if(melhor<0.7){
      setResultado('Utilizar Alcool')
    }else{
      setResultado('Utilizar gasolina')
    }
  }

  return(
    <View>
      <Text style={styles.titulo}>Álcool ou gasolina</Text>

      <Image styles={styles.imagem} source={img}/>


      <TextInput
      style={styles.input}
      placeholder="Digite o valor do álcool"
      onChangeText={setalcool}
      />


      <TextInput
      style={styles.input}
      placeholder="Digite o valor da gasolina"
      onChangeText={setgasolina}
      />




      <Button title='Calcular' color='green' onPress={() => qualMelhor()}/>


      <Text style={styles.resultado}>{resultado}</Text>
    </View>
  )
}

