import {StyleSheet} from 'react-native'


const styles = StyleSheet.create({
  titulo:{
    fontSize: 28, 
    color: 'orange', 
    textAlign: 'center'
    },
  contador: {
    fontSize: 80, 
    color: 'red', 
    textAlign: 'center'
  }
})


export {styles}