import { View, Text } from 'react-native';
import {styles} from './styles';
 
function Projetos(){
  return(
    <Text style={styles.margens}>Projetos : Participou de um tcc de um sistema de gerenciamento de produtos na etec de Peruibe;
    Participou diversos projetos durante as aulas na etec e fatec de praia grande, esses que podem ser encontrados em seu github
    </Text>
  );
}
export default Projetos