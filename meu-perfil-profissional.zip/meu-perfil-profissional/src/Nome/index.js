import { View, Text } from 'react-native';
import {styles} from './styles';
 
function Nome(){
  return(
    <Text style={styles.margens}>Nome : Fernando Faria de Oliveira Machado</Text>
  );
}
export default Nome