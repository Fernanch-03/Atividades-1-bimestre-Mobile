import { View, Text } from 'react-native';
import {styles} from './styles';
 
function DadosPessoais(){
  return(
    <Text style={styles.margens}>Informações pessoais:possui 20 anos, mora em peruíbe, SP.</Text>
  );
}

export default DadosPessoais
