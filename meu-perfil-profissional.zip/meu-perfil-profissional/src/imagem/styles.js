import {StyleSheet} from 'react-native';
    
    const styles = StyleSheet.create({
      dimensoes:{
        width: 150,
        height: 150,
        marginRight: '25%',
        marginLeft: '30%',
        marginTop: 50,
        marginBottom: 40,
      },
    });



export {styles}