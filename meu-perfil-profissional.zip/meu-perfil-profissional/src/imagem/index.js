import { View, Text, Image } from 'react-native';
import {styles} from './styles';

import img from '../../assets/foto.jpg'; 
function Img(){
  return(
    <Image source={img} style = {styles.dimensoes} />
  );
}
export default Img