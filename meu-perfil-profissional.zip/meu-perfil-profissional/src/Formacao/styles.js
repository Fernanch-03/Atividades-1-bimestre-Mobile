import {StyleSheet} from 'react-native';


const styles = StyleSheet.create({
    margens:{
      marginTop: 50,
      marginLeft: 20,
      marginRight:20
  },
});


export {styles}