import { View, Text } from 'react-native';
import {styles} from './styles';
 
function Formacao(){
  return(
    <Text style={styles.margens}>
      Formação : Formado no ensino médio integrado ao ensino tecnico em informatica na Fatec de Peruíbe; 
      está cursando Analise e desenvolvimento de sistemas na FATEC de Praia Grande;
      Possui certificação para utilizar sistemas SAP
    </Text>
  );
}
export default Formacao