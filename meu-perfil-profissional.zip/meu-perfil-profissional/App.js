import React from 'react';
import { View, Text, Image } from 'react-native';

import Img from './src/imagem';
import Nome from './src/Nome';
import DadosPessoais from './src/DadosPessoais';
import Formacao from './src/Formacao';
import Projetos from './src/projetos';


function App() {
  
  return (
    <View style={{ backgroundColor: 'grey', color: 'white', textAlign: 'justify' }}>
        <Img />
        <Nome />
        <DadosPessoais />
        <Formacao />
        <Projetos />
    </View>
  );
}

export default App;
