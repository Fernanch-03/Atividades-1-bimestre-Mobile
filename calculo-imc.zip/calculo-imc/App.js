import { useState } from 'react'
import { View, Text, Button, TextInput, Image } from 'react-native'
import {styles} from './styles'


import img from 'assets/imc.jpg';

export default function App(){
  const [peso, setPeso] = useState(0)
  const [altura, setAltura] = useState(0)
  const [imc, setIMC] = useState('')



  function calculoIMC(peso,altura){
    resultado = peso/(altura*altura)

    if(resultado<18.5){
      setIMC('Abaixo do peeso')
    }
    if(resultado>=18.5 && resultado<25){
      setIMC('Peso Normal')  
    }
    if(resultado>=25 && resultado<30){
      setIMC('Sobrepeso')   
    }
    if(resultado>=30 && resultado<35){
      setIMC('Obesidade grau I')   
    }
    if(resultado>=35 && resultado<40){
      setIMC('Obesidade grau II')   
    }
    if(resultado>=40){
      setIMC('Obesidade grau III ou Morbida')  
    }
  }

  return(
    <View>
      <Text style={styles.titulo}>Calculo IMC</Text>

      <Image source={img}/>

      <TextInput
      style={styles.input}
      placeholder="Peso"
      onChangeText={setPeso}
      />


      <TextInput
      style={styles.input}
      placeholder="Altura"
      onChangeText={setAltura}
      />




      <Button title='Calcular' color='green' onPress={() => calculoIMC(peso,altura)}/>


      <Text style={styles.resultado}>{imc}</Text>
    </View>
  )
}

