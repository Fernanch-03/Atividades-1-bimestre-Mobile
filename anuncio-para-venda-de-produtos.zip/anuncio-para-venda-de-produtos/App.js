import React, { Component } from 'react';
import { View, StyleSheet, ScrollView, Text, Image } from 'react-native';
import {styles} from './styles';

import a1 from 'assets/bigshot.jpg';
import a2 from 'assets/pepsiman.jpg';
import a3 from 'assets/donuts.jpg';

function App(){
  return(
    
    
    <View style={styles.container}>
    <Text style={styles.titulo}>
      Anuncios
    </Text>
      <ScrollView horizontal={true} showsHorizontalScrollIndicator={true}>
        <View style={styles.pepsi}>
        <Image source={a2}/>
        <Text>Beba pepsi hoje!!</Text>
        </View>
        <View style={styles.oport}>
        <Image source={a1}/>
        <Text>Procurando se tornar uma pesoa importante? Clique aqui e saiba como se tornar uma</Text>
        </View>
        <View style={styles.donuts}>
        <Image source={a3}/>
        <Text>Coma donuts hoje</Text>
        </View>
        <View style={styles.pepsi}>
        <Image source={a2}/>
        <Text>Beba pepsi hoje!!</Text>
        </View>
        <View style={styles.oport}>
        <Image source={a1}/>
        <Text>Procurando se tornar uma pesoa importante? Clique aqui e saiba como se tornar uma</Text>
        </View>

      </ScrollView>
    </View>
  )
}



export default App;