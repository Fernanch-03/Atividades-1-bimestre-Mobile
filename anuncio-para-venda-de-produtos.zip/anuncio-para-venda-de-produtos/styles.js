import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
  container:{
    flex: 1
  },
  pepsi:{
    backgroundColor: 'blue',
    height: 400,
    width: 230,
    textAlign: 'center',
  },
  oport:{
    backgroundColor: 'white',
    height: 400,
    width: 230,
    textAlign: 'center',
  },
  donuts:{
    backgroundColor: 'yellow',
    height: 400,
    width: 276,
    textAlign: 'center',
  },
  titulo:{
    fontSize: 25,
    textAlign: 'center',
    color: 'red',
    
  }
})


export {styles}